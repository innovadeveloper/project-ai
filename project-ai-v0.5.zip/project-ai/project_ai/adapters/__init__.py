"""Adaptadores de project-ai. Importar un módulo aquí lo registra.

El ORDEN importa: 'hints' va primero porque los adaptadores de stack pueden
contrastar sus hallazgos (p.ej. maven compara javax/jakarta con el Tomcat del IDE).
"""
from .base import REGISTRY, Adapter, all_adapters, register, run_adapters
from . import hints  # señales transversales (siempre)
from . import maven  # Maven

__all__ = ["REGISTRY", "Adapter", "all_adapters", "register", "run_adapters",
           "hints", "maven"]
