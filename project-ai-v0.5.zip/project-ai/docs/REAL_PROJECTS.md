# Proyectos reales de validación

Rutas en el MacBook del usuario. Lo que sigue son hallazgos de ejecuciones
reales; los fixtures `NETCLIENT` y `HMDM` de `tests/conftest.py` los imitan.

## netclient — C++ / CMake / Conan 2
Ruta: `/Users/kenny/Documents/Projects/C++Projects/netclient`

Estructura vista: `CMakeLists.txt`, `CMakeUserPresets.json`, `conanfile.py`,
`main.cpp`, `include/`, `src/`, `examples/`, `assets/`, `readme.md`
(minúsculas), `new_module_c++.sh`, `tmp.md`, `.vscode/`, `.cache/` (clangd),
`build/` y `build-android/` **versionados en git** (con CMakeCache,
generators de Conan, Makefiles, compile_commands).

Lo que `hints` ya extrae:
- `.vscode/tasks.json`: `conan install . --build=missing -s build_type=Debug`
  → `cmake -B build -S . -DCMAKE_TOOLCHAIN_FILE=build/Debug/generators/...`
  → `cmake --build build`.
- `.vscode/launch.json`: ejecutables `build/sample_test`, `build/event_loop_demo`.
- `readme.md`: flujo para Android (`cmake -S . -B build-android ...`).
- compile_commands en `build-android/`, `build/Debug/`, `build/`.
- Build previo Android: Release, Unix Makefiles, toolchain del NDK.

Pendiente (cmake.py/conan.py): versión mínima de CMake, estándar C++,
targets, requires de Conan, presets `conan-debug`, cross-compilación Android.
Tarea típica que el usuario quiere hacer luego con el modelo local: "crear
un nuevo .cpp que implemente una clase .h del proyecto", "añadir una
dependencia de Conan".

## hmdm — WAR en Tomcat / Maven multi-módulo
Ruta: `/Users/kenny/Documents/Projects/SpringbootProjects/hmdm-server-source-code-service`
(pese al nombre de la carpeta, **no es Spring Boot**: WAR en Tomcat).

Estructura vista: ~1084 archivos; módulos `common/`, `jwt/`, `notification/`,
`plugins/` (con submódulos, p.ej. `plugins/audit`), `server/`;
`.smarttomcat/` (copia de conf de Tomcat local 10.1), `context.xml`,
`BUILD.txt`, `INSTALL.txt`, `TROUBLESHOOTING.txt`, `README.md` extenso,
`readme_build.md` (notas del usuario sobre su entorno: openjdk 17.0.14,
Maven 3.9.11), varios `docker/*/docker-compose.yml`, `Dockerfile` raíz
(`tomcat:9-jdk8-openjdk`), `docker/hmdm-docker-0.1.5/Dockerfile`
(`tomcat:9-jdk11-temurin-jammy`), scripts `hmdm_install.sh`,
`step_001_create_image_and_publish.sh`.

Hallazgos de la ejecución real de `adapters` (v0.2/v0.3):
- README trae la receta: `mvn clean install -pl common,jwt,notification,plugins -am -DskipTests`
  y luego `mvn clean package -pl server -am -DskipTests`.
- WAR → `COPY server/target/launcher.war /usr/local/tomcat/webapps/ROOT.war`.
- Postgres 13 (compose), registro privado `registrydev-service.abexa.pe/hmdm`.
- Contenedor `mqtt-connections` (Mosquitto) usado en README pero no definido
  en ningún compose → `hints.undefined_containers`.
- Riesgo principal: Tomcat local 10.1 vs código probablemente `javax` → el
  WAR no arrancaría. Verificar con `grep -r "import javax.servlet" server/src | head`.

Pendiente de validar con `maven.py` (v0.4) sobre el proyecto real:
- módulos y kinds correctos (incl. submódulos de `plugins/`),
- JDK real del pom (sustituye al 17 de `readme_build.md`),
- endpoints JAX-RS de `server/`,
- aviso javax ↔ Tomcat 10.1.

## Cómo añadir un proyecto nuevo aquí
Ruta, stack, estructura relevante, salida resumida de `adapters`, qué estuvo
mal y qué test lo cubre.
